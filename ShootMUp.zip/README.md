# How to run our game
Hi there Frank or Matthijs! To run our game, simply run 'cabal run' in the root directory.

If that fails, try 'cabal run all'.

We hope you enjoy it!